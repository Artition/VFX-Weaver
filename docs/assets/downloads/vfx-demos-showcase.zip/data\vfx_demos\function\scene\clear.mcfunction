vfx stop @s
kill @e[tag=vfx_showcase]
kill @e[tag=vfx_showcase_cart]
fill 1994 99 1994 2006 104 2006 minecraft:air
tellraw @s {"text":"[VFX showcase] scene cleared","color":"aqua"}
