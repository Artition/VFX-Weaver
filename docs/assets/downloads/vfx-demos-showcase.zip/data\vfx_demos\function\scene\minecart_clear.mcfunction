kill @e[tag=vfx_showcase_cart]
function vfx_demos:scene/clear
